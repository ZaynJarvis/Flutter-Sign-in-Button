enum Buttons {
  /// This is a list of all the library built buttons.
  Email,
  Google,
  GoogleDark,
  Facebook,
  GitHub,
  Apple,
  AppleDark,
  LinkedIn,
  Pinterest,
  Tumblr,
  Twitter,
  Reddit,
  Instagram
}
